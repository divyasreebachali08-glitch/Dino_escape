# 🦖 Dino Escapade - 2D Desert Endless Runner

A high-octane 2D side-scrolling endless action platformer built with HTML5 Canvas, modern CSS, and vanilla JavaScript. Run through the desert, collect meat, charge your strength gauge, unleash explosive fireballs, and shatter rocky obstacles!

---

## 🎮 How to Play

- **Jump / Double Jump**: `Space` or `W` or `Click / Tap Screen`
- **Fireball Attack**: `F` (or tap the on-screen **FIRE!** button when charged)
- **Pause Game**: `P` or `Esc`
- **Toggle Audio**: Click the speaker icon in the top right (or press `M`)
- **Toggle Day / Night**: Click the sun/moon icon in the top right

---

## 🌟 Key Features

- **Double Jump & Agility**: Hop over tall desert rocks or jump twice in mid-air.
- **Power Gauge & Fireball Attack**: Collect meat across the desert track to charge your gauge. Once full, unleash fireballs that explode rock obstacles into debris.
- **Dynamic Day / Night Cycle**: Seamless atmospheric transition between warm daytime desert and cool starry night with automatic night vision.
- **Zero-Dependency Audio Synthesizer**: Custom retro sound effects and background music created on-the-fly via the Web Audio API.
- **Mobile Friendly**: Full touch controls and responsive 16:9 canvas scaling for any screen size.
- **High Score Tracking**: Automatically saves your highest score in your browser.

---

## 🚀 Live Demo

Play online directly in your browser:
👉 **[Play Dino Escapade Online](https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPO_NAME/)**

---

## 🛠️ Tech Stack

- **HTML5 Canvas**: Hardware-accelerated 2D rendering loop.
- **Vanilla JavaScript**: Physics engine, particle effects, parallax scrolling, collision detection, and procedural audio.
- **Vanilla CSS3**: Glassmorphic UI overlays, responsive layout, animated HUD indicators.
- **Web Audio API**: Real-time synthesized chimes, jump springs, fire blasts, and desert music.
