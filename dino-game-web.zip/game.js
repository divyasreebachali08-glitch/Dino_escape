/**
 * Dino Escapade - Core Game Engine
 * 2D Side-scrolling Endless Runner / Action Platformer
 */

// ============================================================================
// AUDIO SYSTEM (Web Audio API Synthesizer - Dependency Free & Zero-Latency)
// ============================================================================
class SoundController {
  constructor() {
    this.ctx = null;
    this.muted = false;
    this.bgmPlaying = false;
    this.bgmTimer = null;
    this.initAudioContext();
  }

  initAudioContext() {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx && !this.ctx) {
        this.ctx = new AudioCtx();
      }
    } catch (e) {
      console.warn("AudioContext not supported", e);
    }
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleMute() {
    this.muted = !this.muted;
    if (this.muted) {
      this.stopBGM();
    } else {
      this.resume();
      this.startBGM();
    }
    return this.muted;
  }

  playJump() {
    if (this.muted || !this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(160, now);
    osc.frequency.exponentialRampToValueAtTime(480, now + 0.16);

    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.16);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.16);
  }

  playEatMeat() {
    if (this.muted || !this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    
    // Juicy double crunch/chime
    [400, 600, 800].forEach((freq, i) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.04);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.5, now + i * 0.04 + 0.08);

      gain.gain.setValueAtTime(0.2, now + i * 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.04 + 0.08);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now + i * 0.04);
      osc.stop(now + i * 0.04 + 0.09);
    });
  }

  playPowerUp() {
    if (this.muted || !this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const notes = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99];
    notes.forEach((freq, i) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now + i * 0.05);

      gain.gain.setValueAtTime(0.18, now + i * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.05 + 0.2);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now + i * 0.05);
      osc.stop(now + i * 0.05 + 0.22);
    });
  }

  playFireShoot() {
    if (this.muted || !this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    
    // Whooshing fiery blast noise + pitch glide
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(650, now);
    osc.frequency.exponentialRampToValueAtTime(120, now + 0.25);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);

    // Noise buffer for crackle
    const bufferSize = this.ctx.sampleRate * 0.25;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }
    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = buffer;

    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.frequency.setValueAtTime(1000, now);
    noiseFilter.frequency.exponentialRampToValueAtTime(300, now + 0.25);

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.25, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);

    whiteNoise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.ctx.destination);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.25);
    whiteNoise.start(now);
    whiteNoise.stop(now + 0.25);
  }

  playRockSmash() {
    if (this.muted || !this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;

    // Heavy low crunch explosion
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(30, now + 0.35);

    gain.gain.setValueAtTime(0.4, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);

    const bufferSize = this.ctx.sampleRate * 0.35;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'lowpass';
    noiseFilter.frequency.setValueAtTime(800, now);
    noiseFilter.frequency.exponentialRampToValueAtTime(100, now + 0.35);

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.35, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);

    noise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.ctx.destination);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.35);
    noise.start(now);
    noise.stop(now + 0.35);
  }

  playGameOver() {
    if (this.muted || !this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    [320, 280, 240, 180, 120].forEach((freq, i) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now + i * 0.08);

      gain.gain.setValueAtTime(0.25, now + i * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.08 + 0.18);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now + i * 0.08);
      osc.stop(now + i * 0.08 + 0.2);
    });
  }

  playClick() {
    if (this.muted || !this.ctx) return;
    this.resume();
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(580, now);
    osc.frequency.exponentialRampToValueAtTime(750, now + 0.05);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.05);
  }

  startBGM() {
    if (this.muted || this.bgmPlaying || !this.ctx) return;
    this.bgmPlaying = true;
    this.playBGMStep(0);
  }

  stopBGM() {
    this.bgmPlaying = false;
    if (this.bgmTimer) {
      clearTimeout(this.bgmTimer);
      this.bgmTimer = null;
    }
  }

  playBGMStep(step) {
    if (!this.bgmPlaying || this.muted || !this.ctx) return;
    this.resume();

    // Catchy upbeat desert runner pentatonic groove (A minor / desert scale)
    const melody = [220, 261.63, 293.66, 329.63, 392.00, 440.00, 392.00, 329.63];
    const bass = [110, 110, 130.81, 146.83];
    const now = this.ctx.currentTime;

    // Bass note
    if (step % 2 === 0) {
      const bFreq = bass[(step / 2) % bass.length];
      const bOsc = this.ctx.createOscillator();
      const bGain = this.ctx.createGain();
      bOsc.type = 'triangle';
      bOsc.frequency.setValueAtTime(bFreq, now);

      bGain.gain.setValueAtTime(0.1, now);
      bGain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);

      bOsc.connect(bGain);
      bGain.connect(this.ctx.destination);
      bOsc.start(now);
      bOsc.stop(now + 0.22);
    }

    // Melody lead
    const mFreq = melody[step % melody.length];
    const mOsc = this.ctx.createOscillator();
    const mGain = this.ctx.createGain();
    mOsc.type = 'sine';
    mOsc.frequency.setValueAtTime(mFreq, now);

    mGain.gain.setValueAtTime(0.06, now);
    mGain.gain.exponentialRampToValueAtTime(0.005, now + 0.12);

    mOsc.connect(mGain);
    mGain.connect(this.ctx.destination);
    mOsc.start(now);
    mOsc.stop(now + 0.13);

    // Rhythm percussion click
    if (step % 2 === 1) {
      const pOsc = this.ctx.createOscillator();
      const pGain = this.ctx.createGain();
      pOsc.type = 'triangle';
      pOsc.frequency.setValueAtTime(80, now);
      pGain.gain.setValueAtTime(0.04, now);
      pGain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
      pOsc.connect(pGain);
      pGain.connect(this.ctx.destination);
      pOsc.start(now);
      pOsc.stop(now + 0.05);
    }

    const stepDuration = 140; // ~107 BPM
    this.bgmTimer = setTimeout(() => {
      this.playBGMStep((step + 1) % 16);
    }, stepDuration);
  }
}

// ============================================================================
// PARTICLE SYSTEM
// ============================================================================
class Particle {
  constructor(x, y, vx, vy, color, size, life, type = 'circle', img = null) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.color = color;
    this.size = size;
    this.maxLife = life;
    this.life = life;
    this.type = type;
    this.img = img;
    this.rot = Math.random() * Math.PI * 2;
    this.vrot = (Math.random() - 0.5) * 0.2;
    this.gravity = 0.2;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.vy += this.gravity;
    this.rot += this.vrot;
    this.life--;
  }

  draw(ctx) {
    const alpha = Math.max(0, this.life / this.maxLife);
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rot);

    if (this.type === 'image' && this.img) {
      const s = this.size;
      ctx.drawImage(this.img, -s / 2, -s / 2, s, s);
    } else if (this.type === 'flame') {
      ctx.fillStyle = this.color;
      ctx.beginPath();
      ctx.arc(0, 0, this.size * alpha, 0, Math.PI * 2);
      ctx.fill();
    } else if (this.type === 'dust') {
      ctx.fillStyle = this.color;
      ctx.beginPath();
      ctx.arc(0, 0, this.size * (1 - alpha * 0.3), 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = this.color;
      ctx.fillRect(-this.size / 2, -this.size / 2, this.size, this.size);
    }

    ctx.restore();
  }
}

// ============================================================================
// MAIN GAME CONTROLLER
// ============================================================================
class DinoGame {
  constructor() {
    this.canvas = document.getElementById('game-canvas');
    this.ctx = this.canvas.getContext('2d');
    this.audio = new SoundController();

    // Virtual resolution matching high quality 16:9 canvas
    this.W = 1600;
    this.H = 900;
    this.groundY = 740;

    // Assets container
    this.assets = {};
    this.assetsLoaded = 0;
    this.totalAssets = 14;

    // Game state: 'LOADING', 'READY', 'PLAYING', 'PAUSED', 'GAMEOVER'
    this.state = 'LOADING';

    // Automatic Day / Night Cycle (Automatic Night Vision)
    this.themeMode = 'auto'; // 'auto', 'night', 'day'
    this.nightBlend = 0;     // 0.0 (full sunset) to 1.0 (full night)
    this.currentPeriod = 'day';
    this.stars = [];
    this.initStars();

    // Game progress & scores
    this.score = 0;
    this.distance = 0;
    this.meatCount = 0;
    this.rocksSmashed = 0;
    this.highScore = parseInt(localStorage.getItem('dino_escapade_highscore') || '0', 10);

    // Speed progression
    this.baseSpeed = 9;
    this.speed = this.baseSpeed;
    this.maxSpeed = 22;

    // Dinosaur player object
    this.dino = {
      x: 180,
      y: this.groundY,
      w: 160,
      h: 140,
      vy: 0,
      isGrounded: true,
      jumpCount: 0,
      maxJumps: 2,
      runCycle: 0,
      poweredUp: false,
      powerGauge: 0, // 0 to 100
      powerTimer: 0,
      powerDuration: 12000, // 12 seconds
      fireCooldown: 0,
      mouthOpen: false,
      stumble: false
    };

    // Entities
    this.obstacles = [];
    this.collectibles = [];
    this.projectiles = [];
    this.particles = [];
    this.floatTexts = [];

    // Background parallax scroll offsets
    this.bgOffset = 0;
    this.clouds = [];
    this.initClouds();

    // Timers
    this.obstacleSpawnTimer = 80;
    this.meatSpawnTimer = 50;

    // UI elements
    this.bindUI();

    // Start asset preloader
    this.loadAssets();

    // Start main game loop
    this.lastTime = performance.now();
    requestAnimationFrame((t) => this.loop(t));
  }

  // --------------------------------------------------------------------------
  // ASSET PRELOADER
  // --------------------------------------------------------------------------
  loadAssets() {
    const assetList = [
      { id: 'bg_day', src: 'day time.jpeg' },
      { id: 'bg_night', src: 'night time.jpeg' },
      { id: 'dino', src: 'assets/dino.png' },
      { id: 'dino_head', src: 'assets/dino_head.png' },
      { id: 'meat', src: 'assets/meat.png' },
      { id: 'rock1', src: 'assets/rock1.png' },
      { id: 'rock2', src: 'assets/rock2.png' },
      { id: 'rock3', src: 'assets/rock3.png' },
      { id: 'rock4', src: 'assets/rock4.png' },
      { id: 'rock5', src: 'assets/rock5.png' },
      { id: 'fireball', src: 'assets/fireball.png' },
      { id: 'rock_debris', src: 'assets/rock_debris.png' },
      { id: 'icon_strength', src: 'assets/icon_strength.png' },
      { id: 'icon_strength_glow', src: 'assets/icon_strength_glow.png' }
    ];

    this.totalAssets = assetList.length;
    let loadedCount = 0;

    const fillBar = document.getElementById('loading-bar-fill');
    const dinoHead = document.getElementById('loading-dino-head');
    const statusText = document.getElementById('loading-status');
    const startBtn = document.getElementById('btn-start-game');

    assetList.forEach(item => {
      const img = new Image();
      img.src = item.src;
      img.onload = () => {
        this.assets[item.id] = img;
        loadedCount++;
        const pct = Math.floor((loadedCount / this.totalAssets) * 100);

        if (fillBar) fillBar.style.width = `${pct}%`;
        if (dinoHead) dinoHead.style.left = `${pct}%`;
        if (statusText) statusText.textContent = `LOADING DESERT TRACK... ${pct}%`;

        if (loadedCount >= this.totalAssets) {
          setTimeout(() => {
            if (statusText) statusText.textContent = "READY FOR ESCAPADE!";
            if (startBtn) startBtn.style.display = "block";
            this.state = 'READY';

            const params = new URLSearchParams(window.location.search);
            if (params.get('screen') === 'gameover' || params.has('gameover')) {
              this.startGame();
              this.score = 1450;
              this.meatCount = 8;
              this.rocksSmashed = 5;
              this.triggerGameOver();
            } else if (params.get('screen') === 'pause' || params.has('pause')) {
              this.startGame();
              this.togglePause();
            }
          }, 300);
        }
      };
      img.onerror = () => {
        console.error("Failed to load:", item.src);
        loadedCount++;
      };
    });
  }

  initClouds() {
    this.clouds = [
      { x: 100, y: 80, speed: 0.4, scale: 0.9 },
      { x: 600, y: 140, speed: 0.3, scale: 0.7 },
      { x: 1100, y: 60, speed: 0.5, scale: 1.1 },
      { x: 1500, y: 120, speed: 0.35, scale: 0.8 }
    ];
  }

  initStars() {
    this.stars = [];
    for (let i = 0; i < 50; i++) {
      this.stars.push({
        x: Math.random() * this.W,
        y: Math.random() * (this.H * 0.42),
        radius: Math.random() * 2.2 + 0.8,
        alphaOffset: Math.random() * Math.PI * 2
      });
    }
  }

  // --------------------------------------------------------------------------
  // UI EVENT BINDING
  // --------------------------------------------------------------------------
  bindUI() {
    // Start game button
    const startBtn = document.getElementById('btn-start-game');
    if (startBtn) {
      startBtn.addEventListener('click', () => {
        this.audio.playClick();
        this.startGame();
      });
    }

    // Pause toggle
    const pauseBtn = document.getElementById('btn-pause');
    if (pauseBtn) {
      pauseBtn.addEventListener('click', () => {
        this.audio.playClick();
        this.togglePause();
      });
    }

    // Audio toggle
    const audioBtn = document.getElementById('btn-audio-toggle');
    if (audioBtn) {
      audioBtn.addEventListener('click', () => {
        const isMuted = this.audio.toggleMute();
        audioBtn.style.opacity = isMuted ? '0.45' : '1';
      });
    }

    // Day / Night Toggle (Auto / Force Night / Force Day)
    const themeBtn = document.getElementById('btn-theme-toggle');
    if (themeBtn) {
      themeBtn.addEventListener('click', () => {
        this.audio.playClick();
        if (this.themeMode === 'auto') {
          this.themeMode = 'night';
          this.nightBlend = 1;
          this.showFloatingNotice('NIGHT VISION: LOCKED');
        } else if (this.themeMode === 'night') {
          this.themeMode = 'day';
          this.nightBlend = 0;
          this.showFloatingNotice('DAY VISION: LOCKED');
        } else {
          this.themeMode = 'auto';
          this.showFloatingNotice('NIGHT VISION: AUTO');
        }
      });
    }

    // Fire Attack button on HUD
    const fireGaugeWidget = document.getElementById('fire-gauge-widget');
    if (fireGaugeWidget) {
      fireGaugeWidget.addEventListener('click', () => {
        if (this.state === 'PLAYING') {
          this.shootFireball();
        }
      });
    }

    // Touch controls
    const touchJump = document.getElementById('btn-touch-jump');
    if (touchJump) {
      touchJump.addEventListener('touchstart', (e) => {
        e.preventDefault();
        this.jump();
      });
      touchJump.addEventListener('mousedown', (e) => {
        e.preventDefault();
        this.jump();
      });
    }

    const touchFire = document.getElementById('btn-touch-fire');
    if (touchFire) {
      touchFire.addEventListener('touchstart', (e) => {
        e.preventDefault();
        this.shootFireball();
      });
      touchFire.addEventListener('mousedown', (e) => {
        e.preventDefault();
        this.shootFireball();
      });
    }

    // Pause menu buttons (Matching pause.jpeg)
    document.getElementById('btn-resume')?.addEventListener('click', () => {
      this.audio.playClick();
      this.togglePause();
    });

    document.getElementById('btn-pause-replay')?.addEventListener('click', () => {
      this.audio.playClick();
      this.hidePauseMenu();
      this.resetGame();
    });

    document.getElementById('btn-pause-home')?.addEventListener('click', () => {
      this.audio.playClick();
      this.hidePauseMenu();
      this.showLoadingScreen();
    });

    // Game Over buttons (Matching loose icons.jpeg)
    document.getElementById('btn-go-replay')?.addEventListener('click', () => {
      this.audio.playClick();
      this.hideGameOverMenu();
      this.resetGame();
    });

    document.getElementById('btn-go-home')?.addEventListener('click', () => {
      this.audio.playClick();
      this.hideGameOverMenu();
      this.showLoadingScreen();
    });

    // Keyboard bindings
    window.addEventListener('keydown', (e) => {
      if (this.state === 'READY' && (e.code === 'Space' || e.code === 'Enter')) {
        this.startGame();
        return;
      }

      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        if (this.state === 'PLAYING') {
          this.jump();
        }
      }

      if (e.code === 'KeyF' || e.code === 'Enter') {
        e.preventDefault();
        if (this.state === 'PLAYING') {
          this.shootFireball();
        }
      }

      if (e.code === 'KeyP' || e.code === 'Escape') {
        e.preventDefault();
        if (this.state === 'PLAYING' || this.state === 'PAUSED') {
          this.togglePause();
        }
      }

      if (e.code === 'KeyK') {
        if (this.state === 'PLAYING') {
          this.triggerGameOver();
        }
      }

      if (e.code === 'KeyM') {
        const isMuted = this.audio.toggleMute();
        const aBtn = document.getElementById('btn-audio-toggle');
        if (aBtn) aBtn.style.opacity = isMuted ? '0.45' : '1';
      }
    });

    // Canvas click to jump
    this.canvas.addEventListener('mousedown', (e) => {
      if (this.state === 'PLAYING') {
        this.jump();
      }
    });
  }

  startGame() {
    const loadingScreen = document.getElementById('loading-screen');
    if (loadingScreen) loadingScreen.classList.add('hidden');
    this.resetGame();
    this.state = 'PLAYING';
    this.audio.startBGM();
  }

  showLoadingScreen() {
    this.state = 'READY';
    const loadingScreen = document.getElementById('loading-screen');
    if (loadingScreen) loadingScreen.classList.remove('hidden');
    const startBtn = document.getElementById('btn-start-game');
    if (startBtn) startBtn.style.display = 'block';
    this.canvas.classList.remove('grayscale-filter');
    this.audio.stopBGM();
  }

  resetGame() {
    this.score = 0;
    this.distance = 0;
    this.meatCount = 0;
    this.rocksSmashed = 0;
    this.speed = this.baseSpeed;

    this.dino.y = this.groundY;
    this.dino.vy = 0;
    this.dino.isGrounded = true;
    this.dino.jumpCount = 0;
    this.dino.poweredUp = false;
    this.dino.powerGauge = 0;
    this.dino.powerTimer = 0;
    this.dino.stumble = false;

    this.obstacles = [];
    this.collectibles = [];
    this.projectiles = [];
    this.particles = [];
    this.floatTexts = [];

    this.obstacleSpawnTimer = 90;
    this.meatSpawnTimer = 40;

    this.updateHUD();
    this.canvas.classList.remove('grayscale-filter');
    this.state = 'PLAYING';
    this.audio.startBGM();
  }

  // --------------------------------------------------------------------------
  // JUMP & FIRE MECHANICS
  // --------------------------------------------------------------------------
  jump() {
    if (this.dino.isGrounded || this.dino.jumpCount < this.dino.maxJumps) {
      this.dino.vy = -21;
      this.dino.isGrounded = false;
      this.dino.jumpCount++;
      this.audio.playJump();

      // Dust particles on jump
      for (let i = 0; i < 6; i++) {
        this.particles.push(new Particle(
          this.dino.x + 40,
          this.groundY + 10,
          (Math.random() - 0.7) * 4,
          (Math.random() - 0.3) * -3,
          '#d78a48',
          Math.random() * 8 + 6,
          25,
          'dust'
        ));
      }
    }
  }

  shootFireball() {
    if (!this.dino.poweredUp) return;
    if (this.dino.fireCooldown > 0) return;

    this.dino.fireCooldown = 15; // Cooldown frames
    this.dino.mouthOpen = true;
    setTimeout(() => { this.dino.mouthOpen = false; }, 250);

    const fx = this.dino.x + this.dino.w - 10;
    const fy = this.dino.y - this.dino.h * 0.72;

    this.projectiles.push({
      x: fx,
      y: fy,
      w: 80,
      h: 36,
      vx: 24,
      vy: 0,
      life: 120
    });

    this.audio.playFireShoot();

    // Muzzle flash particles
    for (let i = 0; i < 8; i++) {
      this.particles.push(new Particle(
        fx,
        fy + 18,
        Math.random() * 6 + 4,
        (Math.random() - 0.5) * 5,
        ['#ffba08', '#f48c06', '#dc2f02'][Math.floor(Math.random() * 3)],
        Math.random() * 10 + 6,
        20,
        'flame'
      ));
    }
  }

  activatePowerUp() {
    this.dino.poweredUp = true;
    this.dino.powerGauge = 100;
    this.dino.powerTimer = this.dino.powerDuration;
    this.audio.playPowerUp();

    // UI Updates
    const strengthWidget = document.getElementById('strength-gauge-widget');
    const fireBtn = document.getElementById('btn-touch-fire');
    const strengthImg = document.getElementById('strength-icon-img');

    if (strengthWidget) strengthWidget.classList.add('powered-up');
    if (strengthImg && this.assets.icon_strength_glow) {
      strengthImg.src = this.assets.icon_strength_glow.src;
    }
    if (fireBtn) fireBtn.style.display = 'flex';

    // Banner notification
    const alert = document.getElementById('power-alert');
    if (alert) {
      alert.classList.add('show');
      setTimeout(() => alert.classList.remove('show'), 2200);
    }
  }

  deactivatePowerUp() {
    this.dino.poweredUp = false;
    this.dino.powerGauge = 0;
    this.dino.powerTimer = 0;

    const strengthWidget = document.getElementById('strength-gauge-widget');
    const fireBtn = document.getElementById('btn-touch-fire');
    const strengthImg = document.getElementById('strength-icon-img');

    if (strengthWidget) strengthWidget.classList.remove('powered-up');
    if (strengthImg && this.assets.icon_strength) {
      strengthImg.src = this.assets.icon_strength.src;
    }
    if (fireBtn) fireBtn.style.display = 'none';
  }

  // --------------------------------------------------------------------------
  // PAUSE AND GAME OVER (Matching pause.jpeg & loose icons.jpeg)
  // --------------------------------------------------------------------------
  togglePause() {
    if (this.state === 'PLAYING') {
      this.state = 'PAUSED';
      this.canvas.classList.add('grayscale-filter');
      document.getElementById('pause-modal')?.classList.add('active');
      this.audio.stopBGM();
    } else if (this.state === 'PAUSED') {
      this.state = 'PLAYING';
      this.canvas.classList.remove('grayscale-filter');
      document.getElementById('pause-modal')?.classList.remove('active');
      this.audio.startBGM();
    }
  }

  hidePauseMenu() {
    this.canvas.classList.remove('grayscale-filter');
    document.getElementById('pause-modal')?.classList.remove('active');
  }

  triggerGameOver() {
    this.state = 'GAMEOVER';
    this.dino.stumble = true;
    this.canvas.classList.add('grayscale-filter');
    this.audio.stopBGM();
    this.audio.playGameOver();

    // Update High Score
    if (this.score > this.highScore) {
      this.highScore = this.score;
      localStorage.setItem('dino_escapade_highscore', this.highScore.toString());
    }

    // Populate Game Over Modal
    document.getElementById('go-score').textContent = this.score;
    document.getElementById('go-highscore').textContent = this.highScore;
    document.getElementById('go-meat').textContent = this.meatCount;
    document.getElementById('go-rocks').textContent = this.rocksSmashed;

    setTimeout(() => {
      document.getElementById('gameover-modal')?.classList.add('active');
    }, 400);
  }

  hideGameOverMenu() {
    this.canvas.classList.remove('grayscale-filter');
    document.getElementById('gameover-modal')?.classList.remove('active');
  }

  // --------------------------------------------------------------------------
  // SPAWNERS (ROCKS ONLY - STRICTLY NO GEMS OR CRYSTALS)
  // --------------------------------------------------------------------------
  spawnObstacle() {
    // Choose one of the 5 stone formations
    const rockIndex = Math.floor(Math.random() * 5) + 1;
    const rockKey = `rock${rockIndex}`;
    const rockImg = this.assets[rockKey];

    let w = 90;
    let h = 85;

    // Tailor obstacle dimensions based on formation
    if (rockIndex === 1) { w = 95; h = 85; }
    else if (rockIndex === 2) { w = 90; h = 95; }
    else if (rockIndex === 3) { w = 80; h = 115; } // tall spire
    else if (rockIndex === 4) { w = 95; h = 105; }
    else if (rockIndex === 5) { w = 110; h = 95; }

    this.obstacles.push({
      x: this.W + 50,
      y: this.groundY - h + 10,
      w: w,
      h: h,
      img: rockImg,
      passed: false
    });
  }

  spawnMeat() {
    // Spawn meat in single or arced jump paths
    const count = Math.random() > 0.6 ? 3 : 1;
    const baseY = this.groundY - 140;

    for (let i = 0; i < count; i++) {
      const offsetX = i * 65;
      const arcY = count > 1 ? baseY - Math.sin((i / (count - 1)) * Math.PI) * 110 : baseY;

      this.collectibles.push({
        x: this.W + 80 + offsetX,
        y: arcY,
        w: 52,
        h: 52,
        bobPhase: Math.random() * Math.PI * 2,
        collected: false
      });
    }
  }

  // --------------------------------------------------------------------------
  // MAIN UPDATE LOOP
  // --------------------------------------------------------------------------
  update(dt) {
    if (this.state !== 'PLAYING') return;

    // Difficulty and speed progression
    this.speed = Math.min(this.maxSpeed, this.baseSpeed + (this.distance / 400));
    this.distance += Math.floor(this.speed * 0.1);
    this.score += Math.floor(this.speed * 0.05);

    // Automatic Day / Night Cycle (Automatic Night Vision)
    if (this.themeMode === 'auto') {
      const cyclePeriod = 420; // 420 meters per full day/night cycle
      const phase = (this.distance % cyclePeriod) / cyclePeriod;

      // 0.00 - 0.38: Golden Sunset Day
      // 0.38 - 0.50: Sunset cross-fading into Night Vision
      // 0.50 - 0.88: Full Night Vision Desert
      // 0.88 - 1.00: Dawn cross-fading back to Golden Sunset
      if (phase < 0.38) {
        this.nightBlend = 0;
        this.currentPeriod = 'day';
      } else if (phase < 0.50) {
        this.nightBlend = (phase - 0.38) / 0.12;
        this.currentPeriod = 'dusk';
      } else if (phase < 0.88) {
        this.nightBlend = 1;
        this.currentPeriod = 'night';
      } else {
        this.nightBlend = 1 - ((phase - 0.88) / 0.12);
        this.currentPeriod = 'dawn';
      }
    } else if (this.themeMode === 'night') {
      this.nightBlend = 1;
      this.currentPeriod = 'night';
    } else if (this.themeMode === 'day') {
      this.nightBlend = 0;
      this.currentPeriod = 'day';
    }

    // Update HUD Sun/Moon Icon based on current lighting
    const sunIcon = document.getElementById('theme-icon-sun');
    const moonIcon = document.getElementById('theme-icon-moon');
    if (sunIcon && moonIcon) {
      if (this.nightBlend >= 0.5) {
        sunIcon.style.display = 'none';
        moonIcon.style.display = 'block';
      } else {
        sunIcon.style.display = 'block';
        moonIcon.style.display = 'none';
      }
    }

    // Parallax background offset
    this.bgOffset = (this.bgOffset + this.speed * 0.4) % this.W;

    // Clouds
    this.clouds.forEach(c => {
      c.x -= c.speed * (this.speed * 0.15);
      if (c.x < -200) c.x = this.W + 100;
    });

    // Dino physics
    this.dino.vy += 0.85; // Gravity
    this.dino.y += this.dino.vy;

    if (this.dino.y >= this.groundY) {
      this.dino.y = this.groundY;
      this.dino.vy = 0;
      this.dino.isGrounded = true;
      this.dino.jumpCount = 0;
    }

    // Run cycle animation
    if (this.dino.isGrounded) {
      this.dino.runCycle += 0.25;
      // Footstep dust puffs
      if (Math.floor(this.dino.runCycle) % 3 === 0 && Math.random() > 0.5) {
        this.particles.push(new Particle(
          this.dino.x + 35,
          this.groundY + 8,
          (Math.random() - 0.7) * 3,
          -Math.random() * 2,
          '#d78a48',
          Math.random() * 6 + 4,
          20,
          'dust'
        ));
      }
    }

    // Power-up Timer & Cooldown
    if (this.dino.poweredUp) {
      this.dino.powerTimer -= 16.6;
      this.dino.powerGauge = Math.max(0, (this.dino.powerTimer / this.dino.powerDuration) * 100);

      // Emit fiery sparks from dino
      if (Math.random() > 0.3) {
        this.particles.push(new Particle(
          this.dino.x + Math.random() * 100 + 20,
          this.dino.y - Math.random() * 100 - 20,
          (Math.random() - 0.7) * 4,
          (Math.random() - 0.5) * -4,
          ['#ffba08', '#f48c06', '#dc2f02'][Math.floor(Math.random() * 3)],
          Math.random() * 7 + 3,
          25,
          'flame'
        ));
      }

      if (this.dino.powerTimer <= 0) {
        this.deactivatePowerUp();
      }
    }

    if (this.dino.fireCooldown > 0) {
      this.dino.fireCooldown--;
    }

    // Spawning obstacles (rocks only)
    this.obstacleSpawnTimer--;
    if (this.obstacleSpawnTimer <= 0) {
      this.spawnObstacle();
      this.obstacleSpawnTimer = Math.floor(Math.random() * 50 + 75 - (this.speed * 1.5));
    }

    // Spawning meat
    this.meatSpawnTimer--;
    if (this.meatSpawnTimer <= 0) {
      this.spawnMeat();
      this.meatSpawnTimer = Math.floor(Math.random() * 60 + 55);
    }

    // Update Obstacles
    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      const obs = this.obstacles[i];
      obs.x -= this.speed;

      // Dino collision check
      const dinoBox = {
        x: this.dino.x + 35,
        y: this.dino.y - this.dino.h + 20,
        w: this.dino.w - 65,
        h: this.dino.h - 30
      };

      const obsBox = {
        x: obs.x + 12,
        y: obs.y + 10,
        w: obs.w - 24,
        h: obs.h - 15
      };

      if (this.checkCollision(dinoBox, obsBox)) {
        this.triggerGameOver();
        return;
      }

      // Pass check
      if (!obs.passed && obs.x + obs.w < this.dino.x) {
        obs.passed = true;
        this.score += 50;
      }

      if (obs.x < -200) {
        this.obstacles.splice(i, 1);
      }
    }

    // Update Meat Collectibles
    for (let i = this.collectibles.length - 1; i >= 0; i--) {
      const meat = this.collectibles[i];
      meat.x -= this.speed;
      meat.bobPhase += 0.08;
      const currentY = meat.y + Math.sin(meat.bobPhase) * 6;

      // Collect check
      const dinoBox = {
        x: this.dino.x + 25,
        y: this.dino.y - this.dino.h + 15,
        w: this.dino.w - 40,
        h: this.dino.h - 20
      };

      const meatBox = {
        x: meat.x,
        y: currentY,
        w: meat.w,
        h: meat.h
      };

      if (this.checkCollision(dinoBox, meatBox)) {
        this.audio.playEatMeat();
        this.meatCount++;
        this.score += 100;
        this.collectibles.splice(i, 1);

        // Power gauge progression (4 meats fill to 100%)
        if (!this.dino.poweredUp) {
          this.dino.powerGauge = Math.min(100, this.dino.powerGauge + 25);
          if (this.dino.powerGauge >= 100) {
            this.activatePowerUp();
          }
        }

        // Floating score popup
        this.floatTexts.push({
          text: '+100 MEAT!',
          x: meat.x,
          y: currentY,
          color: '#ffba08',
          life: 35
        });

        // Golden sparkle burst
        for (let p = 0; p < 10; p++) {
          this.particles.push(new Particle(
            meat.x + meat.w / 2,
            currentY + meat.h / 2,
            (Math.random() - 0.5) * 6,
            (Math.random() - 0.5) * 6,
            '#ffba08',
            Math.random() * 8 + 4,
            25,
            'flame'
          ));
        }
        continue;
      }

      if (meat.x < -100) {
        this.collectibles.splice(i, 1);
      }
    }

    // Update Projectiles (Fireballs)
    for (let p = this.projectiles.length - 1; p >= 0; p--) {
      const proj = this.projectiles[p];
      proj.x += proj.vx;
      proj.life--;

      // Flame trail particles
      this.particles.push(new Particle(
        proj.x + 10,
        proj.y + proj.h / 2 + (Math.random() - 0.5) * 12,
        -Math.random() * 4 - 2,
        (Math.random() - 0.5) * 3,
        ['#ffba08', '#f48c06', '#dc2f02'][Math.floor(Math.random() * 3)],
        Math.random() * 12 + 6,
        18,
        'flame'
      ));

      // Hit test against obstacles (rocks)
      let hit = false;
      for (let o = this.obstacles.length - 1; o >= 0; o--) {
        const obs = this.obstacles[o];
        if (this.checkCollision(proj, obs)) {
          // BLAST AND DESTROY STONE OBSTACLE!
          this.audio.playRockSmash();
          this.rocksSmashed++;
          this.score += 250;

          // Exploding rock debris particles
          const cx = obs.x + obs.w / 2;
          const cy = obs.y + obs.h / 2;

          for (let d = 0; d < 12; d++) {
            this.particles.push(new Particle(
              cx,
              cy,
              (Math.random() - 0.5) * 14,
              (Math.random() - 0.7) * 12,
              '#7f604b',
              Math.random() * 24 + 14,
              45,
              'image',
              this.assets.rock_debris
            ));
          }

          // Fiery smoke explosion
          for (let f = 0; f < 14; f++) {
            this.particles.push(new Particle(
              cx,
              cy,
              (Math.random() - 0.5) * 10,
              (Math.random() - 0.5) * 10,
              ['#ffba08', '#e85d04', '#d00000', '#555'][Math.floor(Math.random() * 4)],
              Math.random() * 18 + 8,
              30,
              'flame'
            ));
          }

          this.floatTexts.push({
            text: '+250 SMASH!',
            x: cx - 40,
            y: cy - 40,
            color: '#ff4d4d',
            life: 40
          });

          this.obstacles.splice(o, 1);
          hit = true;
          break;
        }
      }

      if (hit || proj.life <= 0 || proj.x > this.W + 200) {
        this.projectiles.splice(p, 1);
      }
    }

    // Update Particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const part = this.particles[i];
      part.update();
      if (part.life <= 0) {
        this.particles.splice(i, 1);
      }
    }

    // Update Floating Texts
    for (let i = this.floatTexts.length - 1; i >= 0; i--) {
      const ft = this.floatTexts[i];
      ft.y -= 1.4;
      ft.life--;
      if (ft.life <= 0) {
        this.floatTexts.splice(i, 1);
      }
    }

    this.updateHUD();
  }

  checkCollision(r1, r2) {
    return (
      r1.x < r2.x + r2.w &&
      r1.x + r1.w > r2.x &&
      r1.y < r2.y + r2.h &&
      r1.y + r1.h > r2.y
    );
  }

  // --------------------------------------------------------------------------
  // HUD UI UPDATER
  // --------------------------------------------------------------------------
  updateHUD() {
    document.getElementById('hud-score').textContent = this.score;
    document.getElementById('hud-distance').textContent = `${this.distance}m`;
    document.getElementById('hud-meat').textContent = this.meatCount;

    // Meat Strength circular gauge ring (201 is perimeter)
    const strengthRing = document.getElementById('strength-gauge-ring');
    if (strengthRing) {
      const offset = 201 - (201 * (this.dino.powerGauge / 100));
      strengthRing.style.strokeDashoffset = offset;
      if (this.dino.powerGauge >= 100) {
        strengthRing.classList.add('full');
      } else {
        strengthRing.classList.remove('full');
      }
    }

    // Fireball gauge ring
    const fireRing = document.getElementById('fire-gauge-ring');
    if (fireRing) {
      const firePct = this.dino.poweredUp ? (this.dino.powerTimer / this.dino.powerDuration) : 0;
      fireRing.style.strokeDashoffset = 201 - (201 * firePct);
    }
  }

  // --------------------------------------------------------------------------
  // RENDERING ENGINE
  // --------------------------------------------------------------------------
  draw() {
    this.ctx.clearRect(0, 0, this.W, this.H);

    // 1. Draw Desert Background (Parallax Scrolling with Seamless Automatic Day/Night Cross-Fade)
    const x1 = -this.bgOffset;
    const x2 = x1 + this.W;

    // Draw Sunset Day Background
    if (this.assets.bg_day) {
      this.ctx.save();
      this.ctx.drawImage(this.assets.bg_day, x1, 0, this.W, this.H);
      this.ctx.drawImage(this.assets.bg_day, x2, 0, this.W, this.H);
      this.ctx.restore();
    }

    // Seamlessly blend Night Vision Background on top
    if (this.assets.bg_night && this.nightBlend > 0) {
      this.ctx.save();
      this.ctx.globalAlpha = this.nightBlend;
      this.ctx.drawImage(this.assets.bg_night, x1, 0, this.W, this.H);
      this.ctx.drawImage(this.assets.bg_night, x2, 0, this.W, this.H);
      this.ctx.restore();
    }

    // Twinkling stars when night falls
    if (this.nightBlend > 0.08) {
      this.ctx.save();
      this.stars.forEach(star => {
        const starAlpha = this.nightBlend * (0.35 + 0.65 * Math.sin(Date.now() * 0.003 + star.alphaOffset));
        this.ctx.fillStyle = `rgba(255, 255, 255, ${Math.max(0, starAlpha)})`;
        this.ctx.beginPath();
        const starX = (star.x - this.bgOffset * 0.08 + this.W) % this.W;
        this.ctx.arc(starX, star.y, star.radius, 0, Math.PI * 2);
        this.ctx.fill();
      });
      this.ctx.restore();
    }

    // 2. Draw Clouds with dynamic night tint
    const cR = Math.round(255 * (1 - this.nightBlend) + 215 * this.nightBlend);
    const cG = Math.round(255 * (1 - this.nightBlend) + 225 * this.nightBlend);
    const cB = Math.round(255 * (1 - this.nightBlend) + 250 * this.nightBlend);
    this.ctx.fillStyle = `rgba(${cR}, ${cG}, ${cB}, 0.75)`;
    this.clouds.forEach(c => {
      this.drawPuffyCloud(c.x, c.y, c.scale);
    });

    // 3. Draw Ground Line / Running Track Dust Layer
    const gR = Math.round(180 * (1 - this.nightBlend) + 50 * this.nightBlend);
    const gG = Math.round(70 * (1 - this.nightBlend) + 30 * this.nightBlend);
    const gB = Math.round(30 * (1 - this.nightBlend) + 95 * this.nightBlend);
    this.ctx.fillStyle = `rgba(${gR}, ${gG}, ${gB}, 0.35)`;
    this.ctx.fillRect(0, this.groundY + 8, this.W, 10);

    // 4. Draw Meat Collectibles
    this.collectibles.forEach(meat => {
      const currentY = meat.y + Math.sin(meat.bobPhase) * 6;
      if (this.assets.meat) {
        this.ctx.save();
        this.ctx.translate(meat.x + meat.w / 2, currentY + meat.h / 2);
        this.ctx.rotate(Math.sin(meat.bobPhase) * 0.1);
        this.ctx.drawImage(this.assets.meat, -meat.w / 2, -meat.h / 2, meat.w, meat.h);
        this.ctx.restore();
      }
    });

    // 5. Draw Obstacles (Rocks Only)
    this.obstacles.forEach(obs => {
      if (obs.img) {
        this.ctx.drawImage(obs.img, obs.x, obs.y, obs.w, obs.h);
      } else {
        // Fallback stylized stone
        this.ctx.fillStyle = '#654321';
        this.ctx.fillRect(obs.x, obs.y, obs.w, obs.h);
      }
    });

    // 6. Draw Dinosaur
    this.drawDino();

    // 7. Draw Fireballs
    this.projectiles.forEach(proj => {
      if (this.assets.fireball) {
        this.ctx.drawImage(this.assets.fireball, proj.x, proj.y, proj.w, proj.h);
      } else {
        this.ctx.fillStyle = '#ff5722';
        this.ctx.fillRect(proj.x, proj.y, proj.w, proj.h);
      }
    });

    // 8. Draw Particles
    this.particles.forEach(p => p.draw(this.ctx));

    // 9. Draw Floating Texts
    this.ctx.save();
    this.ctx.font = '24px "Luckiest Guy", cursive';
    this.ctx.textAlign = 'center';
    this.floatTexts.forEach(ft => {
      const alpha = Math.max(0, ft.life / 35);
      this.ctx.globalAlpha = alpha;
      this.ctx.fillStyle = ft.color;
      this.ctx.strokeStyle = '#000';
      this.ctx.lineWidth = 4;
      this.ctx.strokeText(ft.text, ft.x, ft.y);
      this.ctx.fillText(ft.text, ft.x, ft.y);
    });
    this.ctx.restore();
  }

  drawDino() {
    if (!this.assets.dino) return;

    this.ctx.save();
    const dinoX = this.dino.x;
    const dinoY = this.dino.y - this.dino.h;

    // Procedural run squash & bob
    let bobY = 0;
    let tilt = 0;
    if (this.dino.isGrounded && this.state === 'PLAYING') {
      bobY = Math.sin(this.dino.runCycle) * 6;
      tilt = Math.cos(this.dino.runCycle) * 0.04;
    } else if (!this.dino.isGrounded) {
      tilt = this.dino.vy < 0 ? -0.12 : 0.08;
    }

    this.ctx.translate(dinoX + this.dino.w / 2, dinoY + this.dino.h / 2 + bobY);
    this.ctx.rotate(tilt);

    // Fiery Aura when powered up
    if (this.dino.poweredUp) {
      this.ctx.save();
      const glowScale = 1.08 + Math.sin(Date.now() * 0.01) * 0.05;
      this.ctx.scale(glowScale, glowScale);
      this.ctx.shadowColor = '#ffba08';
      this.ctx.shadowBlur = 35;
      this.ctx.drawImage(this.assets.dino, -this.dino.w / 2, -this.dino.h / 2, this.dino.w, this.dino.h);
      this.ctx.restore();
    }

    // Draw main dino sprite
    this.ctx.drawImage(this.assets.dino, -this.dino.w / 2, -this.dino.h / 2, this.dino.w, this.dino.h);

    this.ctx.restore();
  }

  drawPuffyCloud(x, y, scale = 1) {
    this.ctx.save();
    this.ctx.translate(x, y);
    this.ctx.scale(scale, scale);
    this.ctx.beginPath();
    this.ctx.arc(40, 40, 30, 0, Math.PI * 2);
    this.ctx.arc(70, 30, 35, 0, Math.PI * 2);
    this.ctx.arc(105, 38, 28, 0, Math.PI * 2);
    this.ctx.arc(130, 45, 22, 0, Math.PI * 2);
    this.ctx.arc(80, 50, 25, 0, Math.PI * 2);
    this.ctx.fill();
    this.ctx.restore();
  }

  // --------------------------------------------------------------------------
  // GAME LOOP
  // --------------------------------------------------------------------------
  loop(timestamp) {
    const dt = timestamp - this.lastTime;
    this.lastTime = timestamp;

    this.update(dt);
    this.draw();

    requestAnimationFrame((t) => this.loop(t));
  }
}

// Instantiate game when DOM is loaded
window.addEventListener('DOMContentLoaded', () => {
  window.game = new DinoGame();
});
